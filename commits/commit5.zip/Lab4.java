// var. 18371
public class Lab4 {
  public static void main(String[] args) {
  B a = new B();
  B b = new E();
  E c = new E();
  b.p1();
  a.p22();
  a.p28();
  c.p23();
  a.p5();
  c.p8();
  b.p34();
  c.p7();
  b.p30();
  a.p17();
  b.p29(a);
  b.p29(b);
  b.p29(c);
  }
}
previous : 3
